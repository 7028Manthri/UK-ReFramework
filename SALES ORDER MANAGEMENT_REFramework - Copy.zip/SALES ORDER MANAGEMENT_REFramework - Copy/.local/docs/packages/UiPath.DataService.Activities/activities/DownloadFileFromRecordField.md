# Download File From Record Field

`UiPath.DataService.Activities.DownloadFileFromRecordField<TEntity>`

**Package:** `UiPath.DataService.Activities`

Downloads a file from a file-type field on an entity record.

**Category:** Data Service.File

## Properties

`x:TypeArguments` — concrete entity type, e.g. `local:EntityName`. Required at activity declaration.

### Input

| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `EntityId` | `InArgument<Guid>` | Yes | — | Entity GUID from `EntitiesStore.json` |
| `RecordId` | `InArgument<Guid>` | Yes | — | GUID of the source record (`[RequiredArgument]`) |
| `Field` | `InArgument<string>` | Yes | — | Name of the file field (`[RequiredArgument]`, `[Browsable(false)]`) |
| `FilePath` | `InArgument<string>` | No | — | Local path to save the downloaded file. If omitted (`{x:Null}`), the file is saved to the **current execution directory** with its stored filename. |

### Output

| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `DownloadedFileResource` | `OutArgument<ILocalResource>` | No | — | Resource object pointing to the downloaded file |

### Common

| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `ContinueOnError` | `InArgument<bool>` | No | `false` | Continue workflow on error |
| `TimeoutInMs` | `InArgument<int>` | No | `30000` | Timeout in milliseconds |

> **Solution scope properties** (`ScopeValue`, `SolutionEntityKey`, `SolutionEntityName`) are inherited from `BaseEntityActivity` and exist on every activity, but only apply when the project has a SolutionId. For standalone projects, omit them — they're ignored outside solution context. See [overview — Solution Scope Properties](../overview.md#solution-scope-properties-conditional) and [Solution Context](../overview.md#solution-context-folder-vs-tenant-scope).

## XAML Example

```xml
<uda:DownloadFileFromRecordField
    x:TypeArguments="local:ENTITY_NAME"
    FilePath="{x:Null}"
    ContinueOnError="False"
    DisplayName="Download File from ENTITY_NAME"
    DownloadedFileResource="[downloadedFileResource]"
    EntityId="ENTITY_GUID"
    Field="FILE_FIELD_NAME"
    RecordId="[recordIdVariable]"
    TimeoutInMs="30000" />
```

- `Field` — bare string, not expression-wrapped. Use the field name exactly as it appears in `EntitiesStore.json`
- `FilePath` — set to `{x:Null}` when using `DownloadedFileResource` (preferred). If saving to a specific path, use a bare string: `FilePath="C:\downloads\output.pdf"`
- Studio explicitly serializes unused nullable properties as `{x:Null}` — include them for properties applicable to the activity (omit `ScopeValue`/`SolutionEntityKey`/`SolutionEntityName` in standalone projects — they're ignored outside solution context)

### Variable Declaration

```xml
<Variable x:TypeArguments="upr:ILocalResource" Name="downloadedFileResource" />
```

Requires `xmlns:upr="clr-namespace:UiPath.Platform.ResourceHandling;assembly=UiPath.Platform"` on the root `<Activity>` element. See [overview — XAML Namespace Declarations](../overview.md#xaml-namespace-declarations).

## Round-Trip Pattern (Download → Upload)

When copying a file between records, chain `DownloadedFileResource` directly into `UploadFileToRecordField.FileResource`. This preserves the original filename and avoids fabricating temp paths.

```xml
<!-- Step 1: Download — capture DownloadedFileResource, set FilePath to {x:Null} -->
<uda:DownloadFileFromRecordField
    x:TypeArguments="local:ENTITY_NAME"
    FilePath="{x:Null}"
    ContinueOnError="False"
    DisplayName="Download File"
    DownloadedFileResource="[downloadedFileResource]"
    EntityId="ENTITY_GUID"
    Field="FILE_FIELD_NAME"
    RecordId="[sourceRecordId]"
    TimeoutInMs="30000" />

<!-- Step 2: Upload — pass downloadedFileResource as FileResource, set FilePath to {x:Null} -->
<uda:UploadFileToRecordField
    x:TypeArguments="local:ENTITY_NAME"
    FilePath="{x:Null}"
    InputEntity="{x:Null}"
    OutputEntity="{x:Null}"
    ContinueOnError="False"
    DisplayName="Upload File"
    EntityId="ENTITY_GUID"
    ExpansionDepth="2"
    Field="FILE_FIELD_NAME"
    FileResource="[downloadedFileResource]"
    RecordId="[targetRecordId]"
    TimeoutInMs="30000" />
```

> **Prefer `FileResource` over `FilePath`** when the file originates from another activity. `ILocalResource` (from download, `UiPath.Platform.ResourceHandling`) is assignment-compatible with `IResource` (upload input) — no cast needed. Using `FilePath` with a fabricated temp path loses the original filename. The round-trip preserves it.

## When to Use FilePath vs DownloadedFileResource

| Scenario | Use | FilePath value |
|----------|-----|----------------|
| File will be consumed by another activity in the same workflow (e.g., upload to another record) | `DownloadedFileResource` | `{x:Null}` |
| File needs to be saved to a specific user-provided location | `FilePath` | Bare string path (e.g., `C:\downloads\output.pdf`) |
| Both — save to disk AND pass to another activity | Both | Set `FilePath` to the desired path; also capture `DownloadedFileResource` |

**Never fabricate a temp file path.** If you do not need a specific save location, omit `FilePath` (set `{x:Null}`) and use `DownloadedFileResource` — the runtime saves the file to the **current execution directory** with its stored filename, and downstream activities consume it via the resource. Fabricated paths (e.g., `"C:\temp\file_" & guid & ".pdf"`) lose the original filename and create cleanup obligations.

## Key Rules

- `DownloadedFileResource` returns a `UiPath.Platform.ResourceHandling.ILocalResource` — use `.LocalPath` to get the file path
- **For round-trip file copies, omit `FilePath` (set `{x:Null}`) and use `DownloadedFileResource` → `FileResource` chaining** — see pattern above
- `Field` and `FilePath` accept bare strings for literal values — do not wrap in expression brackets (`[...]`) unless the value comes from a variable
