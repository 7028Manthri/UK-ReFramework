$filePath = "C:\Users\SVC-S129426\Documents\UiPath\SALES ORDER MANAGEMENT_REFramework\Framework\InitAllApplications.xaml"
$content = [System.IO.File]::ReadAllText($filePath)

# Step 1: Add outputRecord variable after Vendor_Name variable
$oldVar = '<Variable x:TypeArguments="x:String" Name="Vendor_Name" />'
$newVar = '<Variable x:TypeArguments="x:String" Name="Vendor_Name" />' + "`r`n" + '      <Variable x:TypeArguments="s:UKOrderCopies" Name="outputRecord" />'
$content = $content.Replace($oldVar, $newVar)

# Step 2: Change OutputEntity from [Product_ID] to [outputRecord]
$content = $content.Replace('OutputEntity="[Product_ID]"', 'OutputEntity="[outputRecord]"')

[System.IO.File]::WriteAllText($filePath, $content, [System.Text.UTF8Encoding]::new($false))
Write-Host "File updated successfully."

# Verify
$verify = Select-String -Path $filePath -Pattern "outputRecord|OutputEntity"
$verify | ForEach-Object { Write-Host $_.Line.Trim() }
